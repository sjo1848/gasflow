# GasFlow — App de Reparto de Garrafas (MVP)

Sistema para **gestión de pedidos programados**, **entregas** y **control de garrafas llenas/vacías** para un reparto local.
En esta primera versión el foco es **operación eficiente** (no “delivery instantáneo”).

## Alcance del MVP (resumen)
- Pedidos programados (día + franja horaria) y estados
- Asignación de pedidos a repartidores
- Registro de entrega por domicilio: **llenas entregadas** y **vacías recibidas**
- Control de stock por **cantidades** (llenas/vacías), con conciliación del ciclo
- Panel admin **dentro de la misma app** (sin web por ahora)

## Documentación
- Requisitos: `docs/PRD.md`
- Arquitectura: `docs/ARCHITECTURE.md`
- Backlog: `docs/BACKLOG.md`
- Decisiones (ADR): `docs/adr/`
- Reglas para agentes (Codex): `AGENTS.md`

## Convenciones
- Todo cambio debe actualizar docs relevantes.
- Cada tarea del backlog tiene criterio de aceptación y comando de verificación (cuando haya código).
